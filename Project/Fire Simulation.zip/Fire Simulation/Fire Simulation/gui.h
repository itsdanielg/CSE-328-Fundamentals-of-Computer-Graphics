#pragma once

#ifndef GUI_H
#define GUI_H

void resetVar();
void initGlui();
void adjustGlui();
void callback(int id);
void defaultCallback();
void updateReset();

#endif