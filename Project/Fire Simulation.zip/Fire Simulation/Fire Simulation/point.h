#pragma once

#ifndef POINT_H
#define POINT_H

#include "math.h"

class Point {

public:

	float xPosOne;
	float yPosOne;
	float zPosOne;

	float xPosTwo;
	float yPosTwo;
	float zPosTwo;

};

#endif